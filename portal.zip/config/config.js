/**
 * config.js â€” GoodVibesVendoWifi Captive Portal Frontend Configuration
 *
 * Copy this file to config/config.js (keep config.example.js as a template).
 *
 * SECRETS AND CREDENTIALS MUST NEVER BE PLACED IN THIS FILE.
 * This file ships inside portal-upload.zip.
 */

(function () {
  'use strict';

  window.CONFIG = {

    // ==============================================================
    // BRANDING â€” GoodVibesVendoWifi
    // ==============================================================
    brandName: 'GoodVibesVendoWifi',
    brandTagline: 'Connect to our Guest Network',
    logoUrl: 'assets/images/logo.svg',
    primaryColor: '#2d6a4f',
    accentColor: '#e9f5db',
    textColor: '#2c1810',
    // Left empty on purpose: the real address is injected at build time by
    // inject-secrets.js (SUPPORT_EMAIL), so it is never committed here.
    supportEmail: '',
    supportPhone: '',

    // ==============================================================
    // STORE DETAILS — Contact Support modal / cash-payment store line
    // ==============================================================
    // Rendered at page load by assets/portal.js (index.html) and by each
    // page's own support-modal script. Anything set here wins over the
    // build-time values injected into the HTML. An empty value hides that
    // row, and a raw __TOKEN__ left behind by a skipped inject-secrets run
    // is treated as empty — the modal never shows template tags.
    storeLocation: '',
    facebookPageName: '',
    facebookUrl: '',

    // ==============================================================
    // AUTHENTICATION MODE â€” backend mode (voucher-based)
    // ==============================================================
    mode: 'backend',

    // ==============================================================
    // BACKEND MODE
    // ==============================================================
    // Base URL of your backend server (no trailing slash).
    //
    // EMPTY = call the SAME origin that served this page. That is the correct
    // value whenever this Node backend also serves these HTML files, whether
    // the page was opened via http://localhost:3000, a Termux LAN IP such as
    // http://192.168.1.20:3000, or a Cloudflare Tunnel hostname
    // (https://<name>.trycloudflare.com). It also survives a Cloudflare
    // *quick* tunnel, whose hostname changes every time it restarts.
    //
    // Set an ABSOLUTE url (e.g. 'https://abc-def.trycloudflare.com') ONLY when
    // the HTML is hosted somewhere other than this backend (e.g. uploaded to
    // the Omada controller).
    apiBaseUrl: '',

    // ==============================================================
    // VOUCHER VALIDATION
    // ==============================================================
    // RULE: exactly 6 numeric digits (matches backend/src/utils/voucher-code.js).
    // Keep all three in sync if this ever changes.
    voucher: {
      required: true,
      minLength: 6,
      maxLength: 6,
      pattern: /^\d{6}$/,
      patternHint: 'Voucher code must be exactly 6 digits.',
    },

    // ==============================================================
    // REDIRECT ALLOWLIST
    // ==============================================================
    // Intentionally empty. The guest's requested redirect is NOT restricted
    // here, and none of the pre-auth-whitelisted hosts (this portal's custom
    // domain or LAN address, or the OS captive-probe endpoints) are listed:
    // any host named here becomes eligible as the post-auth destination, and
    // landing on a whitelisted host produces no network-state change, so the OS
    // keeps the captive mini-browser open and re-probes (the client loop).
    // The loop guard lives downstream in success.html's exit block-list.
    allowedRedirectDomains: [],

    defaultRedirectUrl: 'https://www.google.com',

    // ==============================================================
    // TERMS AND CONDITIONS
    // ==============================================================
    termsRequired: true,
    termsUrl: '#terms',
    privacyUrl: '#privacy',

    // ==============================================================
    // STATUS PAGE
    // ==============================================================
    statusPollingInterval: 30000,
        showPauseResume: true,

    // =============================================================
    // CASH PAYMENT TIMER
    // =============================================================
    cashPayment: {
      // Timer duration in seconds (2 minutes 50 seconds)
      timerSeconds: 170,
      // Page to redirect to when timer expires or voucher claimed
      redirectUrl: 'index.html',
    },
    // ==============================================================
    // PRICING TABLE (pricing plans displayed on portal)
    // =============================================================
    pricingPlans: {
      standard: [
        { id: 'standard-1h',   label: '1 Hour',      duration: 60,    price: 500 },
        { id: 'standard-3h',   label: '3 Hours',     duration: 180,   price: 1000 },
        { id: 'standard-12h',  label: '12 Hours',    duration: 720,   price: 2000 },
        { id: 'standard-1d',   label: '24 Hours',    duration: 1440,  price: 3000 },
        { id: 'standard-7d',   label: '7 Days',      duration: 10080, price: 12000 },
        { id: 'standard-30d',  label: '30 Days',     duration: 43200, price: 35000 },
      ],
      premium: [
        { id: 'premium-5h',   label: '5 Hours (Pausable)',  duration: 300,  price: 2500 },
        { id: 'premium-12h',  label: '12 Hours (Pausable)', duration: 720,  price: 4500 },
        { id: 'premium-24h',  label: '24 Hours (Pausable)', duration: 1440, price: 8000 },
      ],
    },

    // =============================================================
    // DUAL-TIER VOUCHER PRICING
    // ==============================================================
        plans: {
      standard: [
        { id: 'standard-1h',   label: '1 Hour',   duration: 60,   price: 5000 },
        { id: 'standard-2h',   label: '2 Hours',  duration: 120,  price: 10000 },
        { id: 'standard-4h',   label: '4 Hours',  duration: 240,  price: 20000 },
        { id: 'standard-8h',   label: '8 Hours',  duration: 480,  price: 40000 },
        { id: 'standard-12h',  label: '12 Hours', duration: 720,  price: 60000 },
        { id: 'standard-24h',  label: '24 Hours', duration: 1440, price: 120000 },
      ],
      premium: [
        { id: 'premium-5h',  label: '5 Hours',  duration: 300,  price: 37500 },
        { id: 'premium-8h',  label: '8 Hours',  duration: 480,  price: 60000 },
        { id: 'premium-24h', label: '24 Hours', duration: 1440, price: 180000 },
      ],
    },
    premiumModifier: 1.5,
    premiumPauseValidityHours: 168,
    adminPage: 'admin.html',

    // ==============================================================
    // CONTROLLER QUERY PARAMETER MAPPING
    // ==============================================================
    paramMap: {
      clientMac:   'clientMac',
      clientIp:    'clientIp',
      apMac:       'apMac',
      ssidName:    'ssidName',
      redirectUrl: 'redirectUrl',
      originalUrl: 'originalUrl',
      authUrl:     'authUrl',
      targetUrl:   'targetUrl',
    },

    // ==============================================================
    // DEVELOPMENT / TESTING
    // ==============================================================
    mockMode: false,
    mockSuccessDelay: 800,

    // ==============================================================
    // PAGE ROUTES
    // ==============================================================
    successPage: 'success.html',
    errorPage:   'error.html',
    statusPage:  'status.html',

    // ==============================================================
    // POST-AUTH SETTLING (race-condition guard)
    // ==============================================================
    // Milliseconds to keep the "Connecting…" screen up AFTER the backend
    // confirms the voucher, before loading success.html. Omada applies the
    // client's firewall/authorization rules asynchronously, so navigating
    // immediately makes the phone's OS re-check internet access too early,
    // mark the network as still-captive, and close the captive mini-browser
    // ("Sign in to network" again). 3000-4000 works for most controllers.
    connectDelayMs: 3500,

  };

})();


